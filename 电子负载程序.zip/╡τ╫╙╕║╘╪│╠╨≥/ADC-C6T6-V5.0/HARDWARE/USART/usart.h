#ifndef __USART_H
#define __USART_H

#include "sys.h"

void My_USART_Init(void);

#endif

