#ifndef __MyTimer_H
#define __MyTimer_H
#include "stm32f10x.h"

void TIM3_Int_Init(u16 arr,u16 psc);

#endif

