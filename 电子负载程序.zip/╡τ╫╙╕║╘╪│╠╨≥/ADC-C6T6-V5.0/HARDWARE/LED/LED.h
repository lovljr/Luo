#ifndef __LED_H
#define __LED_H
#include "sys.h"

#define LED0 PCout(13)
#define LED1 PCout(14)

void Led_Init(void);

#endif

