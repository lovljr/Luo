#ifndef __USART2_H
#define	__USART2_H

#include "stm32f10x.h"
#include <stdio.h>
#include "sys.h" 

#define EN_USART2_RX 			1		//ʹ�ܣ�1��/��ֹ��0������1����
	  	
extern u8 USART2_RX_STA;         		//����״̬���	
extern u8 USART2_RX_CMD;         	


//void Init_hardware_usart2_(u32 bound);
void usart2_Init(u32 bound);

void USART2_IRQHandler(void);

void USART2_SendByte(uint8_t  Data); 

void Uart2_SendCMD1(int dat1, int dat2);
//void Uart2_SendCMD1(int dat1, int dat2, int dat3, int dat4, int dat5);
void Uart2_SendCMD2(int dat1, int dat2);
void Uart2_SendCMD3(int dat1, int dat2);
void Uart2_SendCMD4(int dat1, int dat2, int dat3);

void Uart2_SendCmd(int len);



#endif



