#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "usart.h"
#include "usart2.h"
#include "adc.h"
#include "ds18b20.h"

/*
OLED										DS18B20温度传感器	Water Sensor水位传感器 	TSW-30浊度传感器		TDS传感器
VCC:  3.3v,不要接5v			S:    PA0					S:    PA1								S:    PA6						S:    PA7
GND： GND								+:    3.3v/5v	    +:    3.3v/5v						+:    5v						+:    5v	
SCL： PB8								-:    GND					-:    GND								-:    GND						-:    GND
SDA:  PB9														
任何汉字是一个字占2列
总4行16列								
*/

float WD;
int main(void)
{
	short temperature;
	float NTU,TDS,WL;

	float int_NTU;
	float int_TDS;
	float int_WL;
	u8 int_DST,dec_DST;

	delay_init();
	usart_init(9600);             //  波特率
	usart2_Init(9600);             //  波特率
	
	OLED_Init();                   //  oled初始化
	Adc_Init();
	DS18B20_Init();
	
	OLED_ShowChinese(1,1,0);       //  "浊"
	OLED_ShowChinese(1,3,1);       //  "度"
	OLED_ShowString(1,5,":");
	OLED_ShowString(1,9,"%ntu");
	
	OLED_ShowString(2,1,"TDS :");
	OLED_ShowString(2,9,"*2.93ppm");
	
	OLED_ShowChinese(3,1,2);       //  "水"
	OLED_ShowChinese(3,3,3);       //  "位"
	OLED_ShowString(3,5,":");
	OLED_ShowString(3,9,"mm");

	OLED_ShowChinese(4,1,2);       //  "水"
	OLED_ShowChinese(4,3,4);       //  "温"
	OLED_ShowString(4,5,":");
	
  while(1)
	{
		WD	=  DS18B20_Get_Temp();
		
		//浊度
		NTU = NTU_Value_Conversion();
		//串口发送浊度
		int_NTU = NTU;

		Uart2_SendCMD1(0X01,int_NTU);
		
		OLED_ShowNum(1,6,(float)NTU,3);
		printf("%5.2f",(float)NTU);
		
		//溶解性固体
		TDS = TDS_Value_Conversion();
		//串口发送TDS
		int_TDS = TDS/4096*1400;

		Uart2_SendCMD2(0X02,int_TDS);
		
		OLED_ShowNum(2,6,(float)TDS/4096*1400,3);
		printf("%5.2f",(float)TDS);
		
		//水位
		WL = WL_Value_Conversion();
		//串口发送水位
		int_WL = WL/4096*60;

		Uart2_SendCMD3(0X03,int_WL);
		
		OLED_ShowNum(3,6,(float)WL/4096*60,2);
		printf("%5.2f",(float)WL);
		
		//水温
		temperature=DS18B20_Get_Temp();	
		if(temperature<0)
		{		
			OLED_ShowString(4,6,"-");     //显示负号
			temperature=-temperature;					//转为正数
		}
		else
		{
			OLED_ShowChar(4,6,'+');			//去掉负号
		}
		//串口发送温度
		int_DST = temperature/10;
		dec_DST = temperature%10;
		Uart2_SendCMD4(0X04,int_DST ,dec_DST);
		
		OLED_ShowNum(4,7,temperature/10,2);     //显示整数部分
		OLED_ShowString(4,9,".");
   	OLED_ShowNum(4,10,temperature%10,2);	//显示小数部分 
		OLED_ShowChinese(4,12,5);
		printf("%d.%d", temperature/10,temperature%10);			   
		delay_ms(1000);
	}
}
